const fileInput = document.getElementById("bill");
const selectedFile = document.getElementById("selected-file");

if (fileInput) {

    fileInput.addEventListener(
        "change",
        function () {

            if (
                fileInput.files &&
                fileInput.files.length > 0
            ) {

                const file =
                    fileInput.files[0];

                selectedFile.textContent =
                    "Selected: " + file.name;

            } else {

                selectedFile.textContent = "";

            }

        }
    );
}